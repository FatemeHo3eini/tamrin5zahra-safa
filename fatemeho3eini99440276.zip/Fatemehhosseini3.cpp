#include<iostream>
#include<conio.h>
using namespace std;

int main() {
	int k = 0, i = 0;
	char c[50];
	cout << "string : ";
	gets(c);
	while (c[i++] != '\0')
	{
		if (c[i] == ' ') {
			k++;
		}
	}
	cout << "word number = " << k + 1 << endl;
	_getch();
	return 0;
}
