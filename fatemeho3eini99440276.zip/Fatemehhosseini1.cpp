#include<iostream>
#include<conio.h>
using namespace std;

int Fact(int num) {
	int fact = 1;
	for (int i = 1; i <= num; i++)
		fact *= i;
	return fact;
}

int main() {
	int nums, n;
	cout << "Enter number : ";
	cin >> n;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j <= i; j++) {
			if (j == 0 || j == i)
				nums = 1;
			else
				nums = Fact(i) / (Fact(j) * Fact(i - j));
			cout << nums << "  ";
		}
		cout << endl;
	}
	_getch();
	return 0;
}
