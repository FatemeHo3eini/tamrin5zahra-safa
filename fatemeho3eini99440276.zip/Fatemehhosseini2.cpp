#include<iostream>
#include<conio.h>
using namespace std;

int main() {
	int N, M;
	cout << "Enter two number : ";
	cin >> N >> M;
	for (int k = 1; k <= M; k++) {
		for (int i = 1; i <= N; i++)
			cout << "\t" << k*i;
		cout << endl;
	}
	_getch();
	return 0;
}
